from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import psycopg2

app = FastAPI()

# Настройки CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Конфиг PostgreSQL (используем сервисное имя Kubernetes)
DB_CONFIG = {
    "host": "postgres-service",
    "database": "mydb",
    "user": "admin",
    "password": "mysecretpassword"
}

@app.get("/api/check")
def check_connection():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        conn.close()
        return {"status": "success", "message": "PostgreSQL connection OK"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/version")
def get_version():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        cur.execute("SELECT version();")
        version = cur.fetchone()[0]
        conn.close()
        return {"status": "success", "version": version}
    except Exception as e:
        return {"status": "error", "message": str(e)}