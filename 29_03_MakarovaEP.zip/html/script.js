async function testConnection() {
    const response = await fetch('/api/check');
    const data = await response.json();
    document.getElementById('result').innerHTML = 
        `<strong>Status:</strong> ${data.status}<br>
         <strong>Message:</strong> ${data.message}`;
}

async function getVersion() {
    const response = await fetch('/api/version');
    const data = await response.json();
    if (data.status === "success") {
        document.getElementById('result').innerHTML = 
            `<strong>PostgreSQL Version:</strong><br>${data.version}`;
    } else {
        document.getElementById('result').innerHTML = 
            `<strong>Error:</strong> ${data.message}`;
    }
}